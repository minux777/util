#include <sdsl/vectors.hpp>
#include <vector>
#include <sdsl/bit_vectors.hpp>
#include <sdsl/bp_support_sada.hpp>
#include <iostream>
#include "morton.h"

using namespace std;
using namespace sdsl;


int rle(vector <int> V);

int main(int argc, char * argv[]){
  if(argc < 3){
    cout << "use: " << argv[0] << " <filename> <0|1>" << endl;
    return -1;
  }
  vector <int> V = read_morton_mdt(argv[1], atoi(argv[2]));
  rle(V);
}

int rle(vector <int> V){
  int_vector<16> v(V.size(), 0);
  bit_vector bv(v.size(), 0);
  int pos = 0;
  cout << ".";
  for(unsigned int i = 0; i < V.size(); i++)
    v[i] = V[i];
  cout << ".";
  
  bv[0] = 1;
  for(unsigned int i = 1; i < v.size(); i++)
    if(v[i] != v[i - 1]){
      pos++;
      bv[i] = 1;
      v[pos] = v[i];
    }
  cout << "." << endl;
  v.resize(pos + 1);


  cout << "size of v in  bytes: " << size_in_bytes(v) << endl;
  cout << "length of v: " << v.size() << endl;
  cout << "size of bv in bytes: " << size_in_bytes(bv) << endl;  
  
  dac_vector<> dac_v(v);
  cout << ".";
  rrr_vector<63> rrr_bv(bv);
  cout << ".";
  sd_vector<> sd_bv(bv);
  cout << endl;


  cout << "size of dac_v in bytes: " << size_in_bytes(dac_v) << endl;
  cout << "size of rrr_bv in bytes: " << size_in_bytes(rrr_bv) << endl;
  cout << "size of sd_bv in bytes: " << size_in_bytes(sd_bv) << endl;
  return 0;
}


